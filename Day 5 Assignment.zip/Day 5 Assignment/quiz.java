package com.Quiz;

import com.Quiz.Game;


public class quiz {

  public static void main(String[] args) {
  Game game = new Game();
  
  game.initGame();
  game.play();
   
  }
}
