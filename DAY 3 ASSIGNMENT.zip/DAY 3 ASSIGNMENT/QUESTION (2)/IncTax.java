package com.Tax;
import java.util.Scanner;

public class IncTax {

  public static void main(String[] args) {
  Scanner ws = new Scanner(System.in);
  String name;
  int day;
  int month;
  int year;
  float sal;
  double annsal;
   System.out.println("Enter Employee Details");
   
   System.out.println("Enter Employee Name");
   name=ws.nextLine();
   System.out.println("Enter Day Of Birth");
   day=ws.nextInt();
    System.out.println("Enter Month Of Birth");
   month=ws.nextInt();
    System.out.println("Enter Year Of Year");
   year=ws.nextInt();
   System.out.println("Enter Monthly Salary");
   sal=ws.nextFloat();
   annsal=sal*12;
   
     System.out.println("Your Name Is "+name);

      if (year==1997){
  System.out.println("Your Age Is 23");
     
   }
   else if (year==1996){
  System.out.println("Your Age Is 24");
     
   }
   
   else if (year==1995){
  System.out.println("Your Age Is 25");
     
   }
   
   else if (year==1994){
  System.out.println("Your Age Is 26");
  }
  else {
    System.out.println("You are dead");
  }
    System.out.println("Your Annual Salary Is "+annsal);

  if (annsal >=500000 ){
    System.out.println("Your Inc Tax Is 20%");
  }
  else if (annsal <=500000 && annsal>=300000  ){
    System.out.println("Your Inc Tax Is 15%");
    
      }
  else if (annsal <=300000 && annsal>=200000  ){
    System.out.println("Your Inc Tax Is 10%");
    }
    else if (annsal <=200000 && annsal>=100000 ){
    System.out.println("Your Inc Tax Is 5%%");
    }
    else {
      System.out.println("You dont have to pay tax");
    }
  
  
     
   }

  
  }



   
   
  
  

  


