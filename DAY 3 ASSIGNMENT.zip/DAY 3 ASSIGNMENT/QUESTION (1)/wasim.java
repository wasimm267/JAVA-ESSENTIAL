package com.wasim;
import java.util.Scanner;

public class wasim {

  public static void main(String[] args) {
  Scanner ws=new Scanner(System.in);
  float eng, phy, chem, math, hind; 
    double total, average, percentage;
  
      
    System.out.println("Enter marks of five subjects:");
    System.out.print("Enter marks of English subjects:");
    eng=ws.nextFloat();
    System.out.print("Enter marks of physiology subjects:");
    phy=ws.nextFloat();
    System.out.print("Enter marks of chemistry subjects:");
    chem=ws.nextFloat();
    System.out.print("Enter marks of maths subjects:");
    math=ws.nextFloat();
    System.out.print("Enter marks of Hindi subjects:");
    hind=ws.nextFloat();

    
    total = eng + phy + chem + math + hind;
    average = (total / 5.0);
    percentage = (total / 500.0) * 100;
    if (percentage>=80)
    {
      System.out.println("Grade A");
    }
else if(percentage>=70 && percentage <=80){
  System.out.println("Grade B+");
}
else if(percentage>=60 && percentage <=70){
  System.out.println("Grade B");
}

else if(percentage>=50 && percentage <=60){
  System.out.println("Grade C+");
}

else if(percentage>=40 && percentage <=50){
  System.out.println("Grade C");
}
else if(percentage>=30 && percentage <=40){
  System.out.println("Grade D");
}
  else 
  {
    System.out.println("You Failed Study Hard ");
  }  
    System.out.println("Total marks ="+total);
    System.out.println("Average marks = "+average);
    System.out.println("Percentage = "+percentage);

   }
 
}

   
  
