package com.person;

import com.person.Employee;
import com.person.doctor;


public class Person {

  public static void main(String[] args) {

doctor d=new doctor ();

Employee [] employee = new Employee [3];
for (int i=0; i<3; i++){
  employee[i]=new Employee();
}
for (int i=0; i<3; i++){
  employee [i].getDetails();
 
}
for (int i=0; i<3; i++){
  employee[i].displayDetails();
}
for (int i=0; i<3; i++){
  
}
  }

}
