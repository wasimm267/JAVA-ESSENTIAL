package com.person;

public class doctor extends Employee {


public void appointmentDates(){
System.out.println(" Dates are full");
}
public void addressDisplay(){
  System.out.println("Add : SALT LAKE, KOLKATA");
}

}


