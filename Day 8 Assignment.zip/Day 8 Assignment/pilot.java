package com.person;

public class pilot extends Employee {

public void expHandling()
{
  System.out.println("6 Yrs Of Experience");
}
}
