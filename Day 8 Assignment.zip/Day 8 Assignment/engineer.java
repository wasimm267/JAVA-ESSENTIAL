package com.person;

public class engineer extends Employee {

public void typesOf(){
  System.out.println("Software Engineer");
  
}
public void mbNo(){
  System.out.println("Mobile No - 123456780");
}
}
