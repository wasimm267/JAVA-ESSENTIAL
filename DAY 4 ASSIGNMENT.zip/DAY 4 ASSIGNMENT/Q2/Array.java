package com.main;

public class Array {

  public static void main(String[] args) {
 int [] num=new int [5];
  num[0]=1;
  num[1]=2;
  num[2]=3;
  num[3]=4;
  num[4]=5;
 System.out.println("Odd Numbers Are");
  for (int i=0; i<5; i++){
  
    if(num[i] %2 !=0){
    System.out.println(num[i]);
    }
  }
  }

}
