package com.main;
import java.util.Scanner;

public class avengers {

public String name;
public int age;
public String power;
public String weapon;
public String planet;
Scanner sc=new Scanner (System.in);
public void getDetails(){
  System.out.println("Enter Avenger Name");
  name=sc.nextLine();
  
   System.out.println("Enter Age");
  age=sc.nextInt();
  
  sc.nextLine();
  
   System.out.println("Enter Power");
  power=sc.nextLine();
  
   System.out.println("Enter Weapon");
  weapon=sc.nextLine();
 
  
   System.out.println("Enter Planet");
  planet=sc.nextLine();
  
  
  }
  public void displayDetails(){
    
    System.out.println("The Name Is " +name);
     System.out.println("The Age " +age);
    System.out.println("The Power Is " +power);
    System.out.println("The Weapon Is " +weapon);
    System.out.println("The Planet Is " +planet);
        
  }
}


