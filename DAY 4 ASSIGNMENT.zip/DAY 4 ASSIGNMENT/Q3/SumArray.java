package com.main;
import java.util.Scanner;

public class SumArray {

  public static void main(String[] args) {
  Scanner sc=new Scanner(System.in);
  int tot;
  int [] num = new int [5];
  for (int i=0;i<5;i++)
  {
  System.out.println("Enter The No");
     num[i]=sc.nextInt();
     }
  
 tot = num[0]+num[1]+num[2]+num[3]+num[4];
 
 System.out.println("Your Total No " +tot);
  }
  

  }

